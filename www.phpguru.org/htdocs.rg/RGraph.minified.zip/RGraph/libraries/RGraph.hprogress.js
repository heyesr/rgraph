// THIS FILE HAS BEEN MINIFIED

if(typeof(RGraph) == 'undefined') RGraph = {};RGraph.HProgress = function (id, value, max)
{
this.id = id;this.max = max;this.value = value;this.canvas = document.getElementById(id);this.context = this.canvas.getContext('2d');this.canvas.__object__ = this;this.type = 'hprogress';this.coords = [];this.isRGraph = true;this.currentValue = null;this.uid = RGraph.CreateUID();this.canvas.uid = this.canvas.uid ? this.canvas.uid : RGraph.CreateUID();RGraph.OldBrowserCompat(this.context);this.properties = {
'chart.min':                0,
'chart.colors':             ['#0c0'],
'chart.strokestyle':        '#999',
'chart.tickmarks':          true,
'chart.tickmarks.color':    'black',
'chart.tickmarks.inner':    false,
'chart.gutter.left':        25,
'chart.gutter.right':       25,
'chart.gutter.top':         25,
'chart.gutter.bottom':      25,
'chart.numticks':           10,
'chart.numticks.inner':     50,
'chart.background.color':   '#eee',
'chart.shadow':             false,
'chart.shadow.color':       'rgba(0,0,0,0.5)',
'chart.shadow.blur':        3,
'chart.shadow.offsetx':     3,
'chart.shadow.offsety':     3,
'chart.title':              '',
'chart.title.background':   null,
'chart.title.hpos':         null,
'chart.title.vpos':         null,
'chart.title.bold':         true,
'chart.title.font':         null,
'chart.text.size':          10,
'chart.text.color':         'black',
'chart.text.font':          'Arial',
'chart.contextmenu':        null,
'chart.units.pre':          '',
'chart.units.post':         '',
'chart.tooltips':           null,
'chart.tooltips.effect':    'fade',
'chart.tooltips.css.class': 'RGraph_tooltip',
'chart.tooltips.highlight': true,
'chart.tooltips.event':         'onclick',
'chart.highlight.stroke':   'rgba(0,0,0,0)',
'chart.highlight.fill':     'rgba(255,255,255,0.7)',
'chart.annotatable':        false,
'chart.annotate.color':     'black',
'chart.zoom.factor':        1.5,
'chart.zoom.fade.in':       true,
'chart.zoom.fade.out':      true,
'chart.zoom.hdir':          'right',
'chart.zoom.vdir':          'down',
'chart.zoom.frames':            25,
'chart.zoom.delay':             16.666,
'chart.zoom.shadow':        true,
'chart.zoom.background':    true,
'chart.arrows':                false,
'chart.margin':                0,
'chart.resizable':             false,
'chart.resize.handle.adjust':  [0,0],
'chart.resize.handle.background':null,
'chart.labels.inner':           false,
'chart.labels.specific':       null,
'chart.adjustable':            false,
'chart.scale.decimals':     0,
'chart.scale.point':        '.',
'chart.scale.thousand':     ',',
'chart.key':                [],
'chart.key.background':     'white',
'chart.key.position':       'gutter',
'chart.key.halign':             'right',
'chart.key.shadow':         false,
'chart.key.shadow.color':   '#666',
'chart.key.shadow.blur':    3,
'chart.key.shadow.offsetx': 2,
'chart.key.shadow.offsety': 2,
'chart.key.position.gutter.boxed': false,
'chart.key.position.x':     null,
'chart.key.position.y':     null,
'chart.key.color.shape':    'square',
'chart.key.rounded':        true,
'chart.key.linewidth':      1,
'chart.key.colors':         null,
'chart.key.color.shape':    'square',
'chart.labels.position':     'bottom',
'chart.events.mousemove':    null,
'chart.events.click':        null,
'chart.border.inner':        true
}
if(!this.canvas){
alert('[PROGRESS] No canvas support');return;}
RGraph.Register(this);}
RGraph.HProgress.prototype.Set = function (name, value)
{
if(name == 'chart.label.inner'){
name = 'chart.labels.inner';}
this.properties[name.toLowerCase()] = value;}
RGraph.HProgress.prototype.Get = function (name)
{
if(name == 'chart.label.inner'){
name = 'chart.labels.inner';}
return this.properties[name.toLowerCase()];}
RGraph.HProgress.prototype.Draw = function ()
{
RGraph.FireCustomEvent(this, 'onbeforedraw');this.currentValue = this.value;this.gutterLeft = this.Get('chart.gutter.left');this.gutterRight = this.Get('chart.gutter.right');this.gutterTop = this.Get('chart.gutter.top');this.gutterBottom = this.Get('chart.gutter.bottom');this.width = this.canvas.width - this.gutterLeft - this.gutterRight;this.height = this.canvas.height - this.gutterTop - this.gutterBottom;this.coords = [];this.Drawbar();this.DrawTickMarks();this.DrawLabels();this.context.stroke();this.context.fill();if(this.Get('chart.contextmenu')){
RGraph.ShowContext(this);}
if(this.Get('chart.key').length){
RGraph.DrawKey(this, this.Get('chart.key'), this.Get('chart.colors'));}
if(this.Get('chart.resizable')){
RGraph.AllowResizing(this);}
RGraph.InstallEventListeners(this);RGraph.FireCustomEvent(this, 'ondraw');}
RGraph.HProgress.prototype.Drawbar = function ()
{
if(this.Get('chart.shadow')){
RGraph.SetShadow(this, this.Get('chart.shadow.color'), this.Get('chart.shadow.offsetx'), this.Get('chart.shadow.offsety'), this.Get('chart.shadow.blur'));}
if(RGraph.isOld() && this.Get('chart.shadow')){
this.context.fillStyle = this.Get('chart.shadow.color');this.context.fillRect(this.gutterLeft + this.Get('chart.shadow.offsetx'), this.gutterTop + this.Get('chart.shadow.offsety'), this.width, this.height);}
this.context.fillStyle = this.Get('chart.background.color');this.context.strokeStyle = this.Get('chart.strokestyle');this.context.strokeRect(this.gutterLeft, this.gutterTop, this.width, this.height);this.context.fillRect(this.gutterLeft, this.gutterTop, this.width, this.height);RGraph.NoShadow(this);this.context.fillStyle = this.Get('chart.color');this.context.strokeStyle = this.Get('chart.strokestyle');var margin = this.Get('chart.margin');var barWidth = Math.min(this.width, ((RGraph.array_sum(this.value) - this.Get('chart.min')) / (this.max - this.Get('chart.min')) ) * this.width);if(this.Get('chart.tickmarks.inner')){
var spacing = (RGraph.GetWidth(this) - this.gutterLeft - this.gutterRight) / this.Get('chart.numticks.inner');this.context.lineWidth = 1;this.context.strokeStyle = this.Get('chart.strokestyle');this.context.beginPath();for (var x = this.gutterLeft; x<RGraph.GetWidth(this) - this.gutterRight; x+=spacing){
this.context.moveTo(AA(this, x), this.gutterTop);this.context.lineTo(AA(this, x), this.gutterTop + 2);this.context.moveTo(AA(this, x), RGraph.GetHeight(this) - this.gutterBottom);this.context.lineTo(AA(this, x), RGraph.GetHeight(this) - this.gutterBottom - 2);}
this.context.stroke();}
if(typeof(this.value) == 'number'){
this.context.beginPath();this.context.strokeStyle = this.Get('chart.strokestyle');this.context.fillStyle = this.Get('chart.colors')[0];if(this.Get('chart.border.inner')){
this.context.strokeRect(this.gutterLeft, this.gutterTop + margin, barWidth, this.height - margin - margin);}
this.context.fillRect(this.gutterLeft, this.gutterTop + margin, barWidth, this.height - margin - margin);this.coords.push([this.gutterLeft,
this.gutterTop + margin,
barWidth,
this.height - margin - margin]);} else if(typeof(this.value) == 'object'){
this.context.beginPath();this.context.strokeStyle = this.Get('chart.strokestyle');var startPoint = this.gutterLeft;for (var i=0; i<this.value.length; ++i){
var segmentLength = (this.value[i] / RGraph.array_sum(this.value)) * barWidth;this.context.fillStyle = this.Get('chart.colors')[i];if(this.Get('chart.border.inner')){
this.context.strokeRect(startPoint, this.gutterTop + margin, segmentLength, this.height - margin - margin);}
this.context.fillRect(startPoint, this.gutterTop + margin, segmentLength, this.height - margin - margin);this.coords.push([startPoint,
this.gutterTop + margin,
segmentLength,
this.height - margin - margin]);startPoint += segmentLength;}
}
if(this.Get('chart.arrows')){
var x = this.gutterLeft + barWidth;var y = this.gutterTop;this.context.lineWidth = 1;this.context.fillStyle = 'black';this.context.strokeStyle = 'black';this.context.beginPath();this.context.moveTo(x, y - 3);this.context.lineTo(x + 2, y - 7);this.context.lineTo(x - 2, y - 7);this.context.closePath();this.context.stroke();this.context.fill();this.context.beginPath();this.context.moveTo(x, y + this.height + 4);this.context.lineTo(x + 2, y + this.height + 9);this.context.lineTo(x - 2, y + this.height + 9);this.context.closePath();this.context.stroke();this.context.fill()
if(this.Get('chart.label.inner')){
this.context.beginPath();this.context.fillStyle = 'black';RGraph.Text(this.context, this.Get('chart.text.font'), this.Get('chart.text.size') + 2, this.gutterLeft + barWidth + 5, RGraph.GetHeight(this) / 2, String(this.Get('chart.units.pre') + this.value + this.Get('chart.units.post')), 'center', 'left');this.context.fill();}
}
}
RGraph.HProgress.prototype.DrawTickMarks = function ()
{
var context = this.context;context.strokeStyle = this.Get('chart.tickmarks.color');if(this.Get('chart.tickmarks')){
this.context.beginPath();        
this.tickInterval = this.width / this.Get('chart.numticks');var start = this.Get('chart.tickmarks.zerostart') ? 0 : this.tickInterval;if(this.Get('chart.labels.position') == 'top'){
for (var i=this.gutterLeft + start; i<=(this.width + this.gutterLeft + 0.1); i+=this.tickInterval){
context.moveTo(AA(this, i), this.gutterTop);context.lineTo(AA(this, i), this.gutterTop - 4);}
} else {
for (var i=this.gutterLeft + start; i<=(this.width + this.gutterLeft + 0.1); i+=this.tickInterval){
context.moveTo(AA(this, i), this.gutterTop + this.height);context.lineTo(AA(this, i), this.gutterTop + this.height + 4);}
}
this.context.stroke();}
}
RGraph.HProgress.prototype.DrawLabels = function ()
{
if(!RGraph.is_null(this.Get('chart.labels.specific'))){
return this.DrawSpecificLabels();}
var context = this.context;this.context.fillStyle = this.Get('chart.text.color');var xPoints = [];var yPoints = [];for (i=0; i<this.Get('chart.numticks'); i++){
var font = this.Get('chart.text.font');var size = this.Get('chart.text.size');if(this.Get('chart.labels.position') == 'top'){
var x = this.width * (i/this.Get('chart.numticks')) + this.gutterLeft + (this.width / this.Get('chart.numticks'));var y = this.gutterTop - 6;var valign = 'bottom';} else {
var x = this.width * (i/this.Get('chart.numticks')) + this.gutterLeft + (this.width / this.Get('chart.numticks'));var y = this.height + this.gutterTop + 4;var valign = 'top';}
RGraph.Text(this.context,font,size,x,y, RGraph.number_format(this, (((this.max - this.Get('chart.min')) / this.Get('chart.numticks')) * (i + 1) + this.Get('chart.min')).toFixed(this.Get('chart.scale.decimals')), this.Get('chart.units.pre'), this.Get('chart.units.post')), valign,'center');}
if(this.Get('chart.tickmarks.zerostart')){
if(this.Get('chart.labels.position') == 'top'){
RGraph.Text(this.context,font,size,this.gutterLeft,this.gutterTop - 6,this.Get('chart.units.pre') + Number(this.Get('chart.min')).toFixed(this.Get('chart.scale.decimals')) + this.Get('chart.units.post'),'bottom','center');} else {
RGraph.Text(this.context,font,size,this.gutterLeft,this.canvas.height - this.gutterBottom + 5,this.Get('chart.units.pre') + Number(this.Get('chart.min')).toFixed(this.Get('chart.scale.decimals')) + this.Get('chart.units.post'),'top','center');}
}
if(this.Get('chart.title')){
var vpos = this.gutterTop + this.Get('chart.text.size');if(this.Get('chart.labels.position') == 'top' && this.Get('chart.title.vpos') == null){
this.Set('chart.title.vpos', (this.canvas.height / this.gutterTop) - (this.gutterBottom / this.gutterTop));}
RGraph.DrawTitle(this,
this.Get('chart.title'),
vpos,
0,
this.Get('chart.title.size') ? this.Get('chart.title.size') : this.Get('chart.text.size') + 2);}
}
RGraph.HProgress.prototype.getShape =
RGraph.HProgress.prototype.getBar = function (e)
{
var mouseCoords = RGraph.getMouseXY(e)
for (var i=0; i<this.coords.length; i++){
var mouseCoords = RGraph.getMouseXY(e);var mouseX = mouseCoords[0];var mouseY = mouseCoords[1];var left = this.coords[i][0];var top = this.coords[i][1];var width = this.coords[i][2];var height = this.coords[i][3];var idx = i;if(mouseX >= left && mouseX <= (left + width) && mouseY >= top && mouseY <= (top + height) ){
var tooltip = RGraph.parseTooltipText(this.Get('chart.tooltips'), idx);return {
0: this, 1: left, 2: top, 3: width, 4: height, 5: idx,
'object':this, 'x':left, 'y':top, 'width': width, 'height': height, 'index': idx, 'tooltip': tooltip
}
}
}
}
RGraph.HProgress.prototype.getValue = function (e)
{
var mouseXY = RGraph.getMouseXY(e);var value = (mouseXY[0] - this.gutterLeft) / this.width;value *= this.max - this.Get('chart.min');value += this.Get('chart.min');if(mouseXY[0] < this.gutterLeft){
value = this.Get('chart.min');}
if(mouseXY[0] > (this.canvas.width - this.gutterRight) ){
value = this.max
}
return value;}
RGraph.HProgress.prototype.Highlight = function (shape)
{
RGraph.Highlight.Rect(this, shape);}
RGraph.HProgress.prototype.getObjectByXY = function (e)
{
var mouseXY = RGraph.getMouseXY(e);if(
mouseXY[0] > this.Get('chart.gutter.left')
&& mouseXY[0] < (this.canvas.width - this.Get('chart.gutter.right'))
&& mouseXY[1] > this.Get('chart.gutter.top')
&& mouseXY[1] < (this.canvas.height - this.Get('chart.gutter.bottom'))
){
return this;}
}
RGraph.HProgress.prototype.Adjusting_mousemove = function (e)
{
if(RGraph.Registry.Get('chart.adjusting') && RGraph.Registry.Get('chart.adjusting').uid == this.uid){
var mouseXY = RGraph.getMouseXY(e);var value = this.getValue(e);if(typeof(value) == 'number'){
RGraph.FireCustomEvent(this, 'onadjust');this.value = Number(value.toFixed(this.Get('chart.scale.decimals')));RGraph.Redraw();}
}
}
RGraph.HProgress.prototype.DrawSpecificLabels = function ()
{
var labels = this.Get('chart.labels.specific');if(labels){
var font = this.Get('chart.text.font');var size = this.Get('chart.text.size');var valign = (this.Get('chart.labels.position') == 'top' ? 'bottom' : 'top');var step = this.width / (labels.length - 1);this.context.beginPath();this.context.fillStyle = this.Get('chart.text.color');for (var i=0; i<labels.length; ++i){
RGraph.Text(this.context,
font,
size,
this.gutterLeft + (step * i),
this.Get('chart.labels.position') == 'top' ? this.gutterTop - 7  : this.canvas.height - this.gutterBottom + 7,
labels[i],
valign,
'center');}
this.context.fill();}
}